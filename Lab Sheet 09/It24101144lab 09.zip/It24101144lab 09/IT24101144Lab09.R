setwd("C:\\Users\\Sayun\\Desktop\\SLIIT\\Y2S1\\PS\\It24101144lab 09")

# Set seed for reproducibility (optional, but recommended for consistent results)
set.seed(42)

# i. Generate random sample of size 25 from N(45, 2)
bake_times <- rnorm(25, mean = 45, sd = 2)
print(bake_times)


# ii. One-sample t-test: H0: mu >= 46 vs Ha: mu < 46 at alpha=0.05
t_test_bake <- t.test(bake_times, mu = 46, alternative = "less")
print(t_test_bake)


# Conclusion: Significant evidence that average baking time < 46 minutes.
