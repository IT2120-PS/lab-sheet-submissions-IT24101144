setwd("C:\\Users\\it24101144\\Downloads\\Lab 8")

data<-read.table("Exercise - LaptopsWeights.txt",header=TRUE)
fix(data)
attach(data)
##Q1-population mean
popmn<-mean(Weight.kg.)
popmn
popvar<-var(Weight.kg.)
popvar
##Population standard deviation
pop_sd <- sd(Weight.kg.)
pop_sd
##Q2
samples<-c()
n<-c
for(i in 1:25){
  s<-sample(Weight.kg.,6,replace=TRUE)
  samples<-cbind(samples,s)
  n<-c(n,paste('s,i'))
}

s.means<-apply(samples,2,mean)
s.means
s.sd<-apply(samples,2,sd)
s.sd

#Q3
samplemean<-mean(s.means)
samplemean
sample_sd<-sd(s.sd)
sample_sd
#relationship
##The mean of the sample mean is close to the population mean(Law of large numbers)
##The standard deviation of the sample means(standard error)is smaller than thepopulation standard deviation
##It approximates population_sd/sqrt(sample size)

